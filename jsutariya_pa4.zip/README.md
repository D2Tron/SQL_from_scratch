Run the program in 2 separate terminals.

For the first terminal follow this command to run the program:
g++ jsutariya_pa4.cpp -o proj1
./proj1

For the second terminal follow this command to run the program:
g++ jsutariya_pa4.cpp -o proj2
./proj2

For the actual SQL commands, check the PA4_test.sql file for instructions and the order of the commands.